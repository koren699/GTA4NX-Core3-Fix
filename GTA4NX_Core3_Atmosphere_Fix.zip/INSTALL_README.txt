GTA4NX Core 3 - tested forwarder NPDM override
Title ID: 03DB149512496000

1. Back up sdmc:/atmosphere/contents/03DB149512496000/ if present.
2. Close GTA IV and unpack the atmosphere folder into SD root.
3. Reboot Atmosphere and launch through HOME-menu forwarder.
4. On error remove only atmosphere/contents/03DB149512496000/exefs/main.npdm and reboot.

Not a 30 FPS guarantee. Requires the matching title ID and supported ExeFS override.
